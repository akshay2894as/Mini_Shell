# Mini_Shell
Minishell is a simple Linux shell implemented in C that supports built-in and external commands.  It uses system calls like fork(), execvp(), waitpid(), chdir(), and signal handling to execute commands.
